<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="template/css.css" type="text/css">
    </head>
    <body>
        <div id="container">
            <header>
                <a href="index.php">COMPUTER ABC</a>
            </header>

        </div>
        <div id="main-wrapper">
            <?php echo $html?>
        </div>
    </body>
</html>