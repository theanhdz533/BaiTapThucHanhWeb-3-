<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Gửi Mail</title>
</head>
<body>
    <h1>Mail Được Gửi Từ Name {{ $name }}</h1>
    <h4>Với nội dung {{ $body }}</h4>
</body>
</html>

