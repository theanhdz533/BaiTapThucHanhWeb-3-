<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mail To Customer</title>
</head>
<body>
    Xin chào {{ $name }} ! <br>
    {{ $type }}<br>
    Mã khôi phục là : {{ $code }} <br>
    Nếu bạn không yêu cầu hãy bỏ qua mail này! <br>
    Xin cảm ơn !
</body>
</html>