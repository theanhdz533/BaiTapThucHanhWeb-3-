<?php
$config['host']='localhost';
$config['user']='root';
$config['pass']='admin';
$config['data']='tintuc';
?>